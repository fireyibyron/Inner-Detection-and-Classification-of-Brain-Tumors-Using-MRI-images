import cv2
import os
import tensorflow as tf
from keras.models import load_model
import numpy as np
import mahotas as mh
import scipy.stats
import matplotlib.pyplot as plt
from skimage import filters, measure

# Loading the saved trained model
model = load_model('braintumors10epochs.h5')

# Setting the input size for the model
input_size = 64

# Loading the image and mask in grayscale
mri_image = cv2.imread('dataset/Testing/glioma_tumor/image(9).jpg', cv2.IMREAD_GRAYSCALE)
mask = cv2.imread('dataset/Testing/glioma_tumor/image(9).jpg', cv2.IMREAD_GRAYSCALE)

# Loading the image in color
img = cv2.imread('dataset/Testing/glioma_tumor/image(9).jpg')

# Resizing the image for prediction
img = cv2.resize(img, (input_size, input_size))
img_array = img.reshape(1, input_size, input_size, 3)

# Predicting the type of tumor
tdc=model.predict(img_array)
indices = tdc.argmax()
type = indices
if indices==0:
    type = "Glioma Tumor"
elif indices==1:
    type = "Meningioma Tumor"
elif indices==2:
    type = "No Tumor"
else:
    type = "Pituitary Tumor"

# Creating a binary mask and a segmented image
_, binary_mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)
segmented = cv2.addWeighted(mri_image, 0.7, binary_mask, 0.3, 0)

# Plotting the original and segmented images
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(mri_image, cmap='gray')
plt.title('Original MRI Image')
plt.subplot(1, 2, 2)
plt.imshow(segmented, cmap='gray')
plt.title('Segmented Image')
plt.show()

# Ensuring the mask is binary
mask = mask > filters.threshold_otsu(mask)

# Extracting the tumor region
tumor_region= np.where(mask, mri_image, 0)

# Calculating the features
mean = np.mean(tumor_region)
std_dev = np.std(tumor_region)
entropy = measure.shannon_entropy(tumor_region)
rms = np.sqrt(np.mean(tumor_region**2))
variance = np.var(tumor_region)
smoothness = 1 - 1 / (1 + variance)
kurtosis = scipy.stats.kurtosis(tumor_region.flatten())
skewness = scipy.stats.skew(tumor_region.flatten())
# Calculating the Haralick features
haralick_features = mh.features.haralick(tumor_region.astype(int))
contrast = haralick_features[:, 1]
correlation = haralick_features[:, 2]
energy = haralick_features[:, 4]
homogeneity = haralick_features[:, 8]

# Printing the classification and features
if (indices == 0) or (indices == 1) or (indices == 3):
    print('Inner Brain Tumor Detected')
    print(f'Classification:\t{type}\n\n')
    print(f"Mean: {mean}")
    print(f"Standard Deviation: {std_dev}")
    print(f"Entropy: {entropy}")
    print(f"RMS: {rms}")
    print(f"Variance: {variance}")
    print(f"Smoothness: {smoothness}")
    print(f"Kurtosis: {kurtosis}")
    print(f"Skewness: {skewness}")
    print(f"Contrast: {contrast}")
    print(f"Correlation: {correlation}")
    print(f"Energy: {energy}")
    print(f"Homogeneity: {homogeneity}")
else:
    print('No Brain Tumor Detected')
    print(f'Classification:\t{type}\n\n')
    print(f"Mean: {mean}")
    print(f"Standard Deviation: {std_dev}")
    print(f"Entropy: {entropy}")
    print(f"RMS: {rms}")
    print(f"Variance: {variance}")
    print(f"Smoothness: {smoothness}")
    print(f"Kurtosis: {kurtosis}")
    print(f"Skewness: {skewness}")
    print(f"Contrast: {contrast}")
    print(f"Correlation: {correlation}")
    print(f"Energy: {energy}")
    print(f"Homogeneity: {homogeneity}")