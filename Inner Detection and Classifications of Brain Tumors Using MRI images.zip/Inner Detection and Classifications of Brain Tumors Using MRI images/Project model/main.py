# Importing necessary libraries
import cv2
import os
import tensorflow as tf
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
import matplotlib.pyplot as plt
from keras.preprocessing import image
from keras.utils import to_categorical
from keras.models import Sequential
from sklearn.metrics import accuracy_score
from keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten,  Dense

# Initialising dataset and label lists
dataset = []
label = []
# Setting the input size for the model
input_size = 64
# Defining the labels for the four types of tumors
labels = ['glioma_tumor', 'meningioma_tumor', 'no_tumor', 'pituitary_tumor']

# Loading and preprocessing the training images
for i in labels:
    datasets_path = os.path.join('dataset/Training', i)
    for j in os.listdir(datasets_path):
        img = cv2.imread(os.path.join(datasets_path, j))
        img = cv2.resize(img, (input_size, input_size))
        dataset.append(np.array(img))
        label.append(i)

# Loading and preprocessing the testing images
for i in labels:
    datasets_path = os.path.join('dataset/Testing', i)
    for j in os.listdir(datasets_path):
        img = cv2.imread(os.path.join(datasets_path, j))
        img = cv2.resize(img, (input_size, input_size))
        dataset.append(np.array(img))
        label.append(i)

# Converting the dataset and label lists to numpy arrays
dataset = np.array(dataset)
label = np.array(label)

# Shuffling the dataset and labels
dataset, label = shuffle(dataset, label, random_state=150)
# Printing the shape of the dataset
print(f'shape of the dataset: {dataset.shape}')

# Splitting the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(dataset, label, test_size=0.2, random_state=150)

# Printing the shape of the training set
print(f'shape of the training set: {X_train.shape}\t{y_train.shape}')
# Printing the shape of the testing set
print(f'shape of the testing set: {X_test.shape}\t{y_test.shape}\n')

# Converting the labels to integers and then to categorical format
y_train_new = []
for i in y_train:
    y_train_new.append(labels.index(i))
y_train=y_train_new
y_train = tf.keras.utils.to_categorical(y_train)

y_test_new = []
for i in y_test:
    y_test_new.append(labels.index(i))
y_test=y_test_new
y_test = tf.keras.utils.to_categorical(y_test)

# Defining the architecture of the model
model = Sequential()

model.add(Conv2D(32,(3,3),activation = 'relu',input_shape=(input_size,input_size,3)))
model.add(Conv2D(64,(3,3),activation='relu'))
model.add(MaxPooling2D(2,2))

model.add(Conv2D(64,(3,3),activation='relu'))
model.add(Conv2D(64,(3,3),activation='relu'))
model.add(MaxPooling2D(2,2))

model.add(Conv2D(128,(3,3),activation='relu'))
model.add(MaxPooling2D(2,2))

model.add(Conv2D(128,(3,3),activation='relu'))
model.add(MaxPooling2D(2,2))

model.add(Flatten())
model.add(Dense(256,activation = 'relu'))
model.add(Dropout(0.3))
model.add(Dense(4,activation='softmax'))

# # Printing the model architectural summary
# model.summary()

# # Visualising the model
# from tensorflow.keras.utils import plot_model
# plot_model(model, to_file='model_plot.png', show_shapes=True, show_layer_names=True)

# Compiling the model
model.compile(optimizer = 'adam', loss = 'categorical_crossentropy', metrics = ['accuracy'])
# Training the model
history = model.fit(X_train, y_train, epochs=10, validation_split=0.1, verbose=2)

# Saving the trained model
model.save('braintumors10epochs.h5')

# Extracting accuracy history from the model's training history
acc = history.history['accuracy']
# Extracting validation accuracy history from the model's training history
val_acc = history.history['val_accuracy']
# Creating a range object that represents the number of completed epochs
epochs = range(len(acc))
# Creating a new figure for plotting
fig = plt.figure(figsize=(14,7))
#Printing the Tittle of the graph being plotted
plt.title('Accuracy')
# Plotting the training accuracy
plt.plot(epochs,acc,'r',label="Training Accuracy")
# Plotting the validation accuracy
plt.plot(epochs,val_acc,'b',label="Validation Accuracy")
# Adding a legend to the plot
plt.legend(loc='upper left')
# Displaying the plot
plt.show()

# Extracting loss history from the model's training history
loss = history.history['loss']
# Extracting validation loss history from the model's training history
val_loss = history.history['val_loss']
# Creating a range object that represents the number of completed epochs (same as before)
epochs = range(len(loss))
# Creating a new figure for plotting
fig = plt.figure(figsize=(14,7))
#Printing the Tittle of the graph being plotted
plt.title('Loss')
# Plotting the training loss
plt.plot(epochs,loss,'r',label="Training loss")
# Plotting the validation loss
plt.plot(epochs,val_loss,'b',label="Validation loss")
# Adding a legend to the plot
plt.legend(loc='upper left')
# Displaying the plot
plt.show()

# Evaluating the model on the test data
print('\n')
loss, accuracy = model.evaluate(X_test, y_test)
print(f'Test loss: {loss}')
print(f'Test accuracy: {accuracy}')
